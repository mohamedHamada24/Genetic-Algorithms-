 import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class MainTermin2 {

    public static void main(String[] args) {
        String sequence = Examples.SEQ20; // "10100110100101100101"
        int directionLength = sequence.length() - 1; // 19
        int popSize = 100;
        int maxGenerations = 100;

        // 1. Create Initial Population (Gen 0)
        List<Faltung> population = new ArrayList<>();
        for (int i = 0; i < popSize; i++) {
            String randomDirs = PopulationGenerator.generateRandomDirections(directionLength);
            Faltung f = new Faltung(sequence, randomDirs);
            FitnessCalculator.evaluate(f);
            population.add(f);
        }

        // Keep track of the best overall solution found across all generations
        Faltung bestEver = getBest(population);

        // 2. Open CSV file for writing (6 required columns)
        try (PrintWriter writer = new PrintWriter(new FileWriter("ga_log.csv"))) {
            // Header requirement from slide/task sheet
            writer.println("Generation;AvgFitness;BestGenFitness;BestEverFitness;BestEverHH;BestEverOverlaps");

            for (int gen = 0; gen <= maxGenerations; gen++) {

                // Calculate generation statistics
                double totalFitness = 0.0;
                Faltung bestInGen = population.get(0);

                for (Faltung f : population) {
                    totalFitness += f.getFitness();
                    if (f.getFitness() > bestInGen.getFitness()) {
                        bestInGen = f;
                    }
                }

                double avgFitness = totalFitness / popSize;

                // Update best overall
                if (bestInGen.getFitness() > bestEver.getFitness()) {
                    bestEver = bestInGen;
                }

                // Write current generation metrics to CSV (Semi-colon separated for Excel)
                writer.printf("%d;%.6f;%.6f;%.6f;%d;%d\n",
                        gen, avgFitness, bestInGen.getFitness(),
                        bestEver.getFitness(), bestEver.getHhContactsCount(), bestEver.getOverlapsCount());

                // Stop loop after logging generation 100
                if (gen == maxGenerations) break;

                // 3. Selection Step for next generation (No Crossover / No Mutation yet)
                population = Selection.selectNextGeneration(population);
            }

            System.out.println("Finished 100 Generations!");
            System.out.println("Log successfully saved to 'ga_log.csv'");

        } catch (IOException e) {
            System.err.println("Error writing to CSV: " + e.getMessage());
        }

        // Save the best fold image at the end of your run
        Visualization.drawFaltung(bestEver, "best_fold.png");
    }

    private static Faltung getBest(List<Faltung> population) {
        Faltung best = population.get(0);
        for (Faltung f : population) {
            if (f.getFitness() > best.getFitness()) {
                best = f;
            }
        }
        return best;
    }
}
